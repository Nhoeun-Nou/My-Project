@echo off
title Insatll_AnyDesk(.crd)
set "Des=C:\Users\NEC\Desktop"
set "Tar=%Des%\AnyDesk\AnyDesk.exe"
set "Key=rundll32.exe keymgr.dll,KRShowKeyMgr"

echo 1-Add Windows Credentials:
start /wait "" %Key% &echo:

echo 2-Install AnyDesk:
echo: &runas /savecred /user:administrator "%Tar%" >nul 2>&1 
pause >nul

echo 3-Remove Windows Credentials:
start /wait "" %Key% &echo:

echo 4-Romove Files:
taskkill /f /im AnyDesk.exe
del /q "%Des%\AnyDesk.zip"
cd /d %~pd0 &cd ..
rd /s /q "%Des%\AnyDesk"
